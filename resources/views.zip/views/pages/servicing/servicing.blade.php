@extends('layouts.default')

@section('content')
<!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">Loan Servicing</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item active"><a href="#">Servicing</a></li>
                </ol>
            </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

    <style>
        .color-palette {
        height: 35px;
        line-height: 35px;
        text-align: right;
        padding-right: .75rem;
        }
        
        .color-palette.disabled {
        text-align: center;
        padding-right: 0;
        display: block;
        }
        
        .color-palette-set {
        margin-bottom: 15px;
        }

        .color-palette span {
        display: none;
        font-size: 12px;
        }

        .color-palette:hover span {
        display: block;
        }

        .color-palette.disabled span {
        display: block;
        text-align: left;
        padding-left: .75rem;
        }

        .color-palette-box h4 {
        position: absolute;
        left: 1.25rem;
        margin-top: .75rem;
        color: rgba(255, 255, 255, 0.8);
        font-size: 12px;
        display: block;
        z-index: 7;
        }
    </style>

<div class="col-md-6">
    <div class="card card-danger">
      <div class="card-header">
        <h3 class="card-title">Servicing</h3>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <div id="accordion">
          <!-- we are adding the .class so bootstrap.js collapse plugin detects it -->
          <div class="card card-danger">
            <div class="card-header">
              <h4 class="card-title">
                <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                  Call Scripts
                </a>
              </h4>
            </div>
            <div id="collapseOne" class="panel-collapse collapse in">
                <div class="card-body">
                  
                    <table class="table">
                      <thead>
                        <tr>
                          <th>File Name</th>
                          <th>File Size</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>

                        <tr>
                          <td>Servicing Call Scripts.docx</td>
                          <td>49.8 kb</td>
                          <td class="text-right py-0 align-middle">
                            <div class="btn-group btn-group-sm">
                              <a href="#" class="btn btn-secondary"><i class="fas fa-eye"></i></a>
                              <a href="#" class="btn btn-info"><i class="fas fa-file-download"></i></a>
                            </div>
                          </td>
      
                      </tbody>
                    </table>

                </div>
            </div>
          </div>
          </div>
          <div class="card card-danger">
            <div class="card-header">
              <h4 class="card-title">
                <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                  Documents
                </a>
              </h4>
            </div>
            <div id="collapseTwo" class="panel-collapse collapse">
              <div class="card-body">

                <table class="table">
                    <thead>
                      <tr>
                        <th>File Name</th>
                        <th>File Size</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>

                      <tr>
                        <td>Authorization Agreement for Automatic Mortgage Payment.pdf</td>
                        <td>394.2 kb</td>
                        <td class="text-right py-0 align-middle">
                          <div class="btn-group btn-group-sm">
                            <a href="#" class="btn btn-secondary"><i class="fas fa-eye"></i></a>
                            <a href="#" class="btn btn-info"><i class="fas fa-file-download"></i></a>
                          </div>
                        </td>
    
                    </tbody>
                  </table>

              </div>
            </div>
          </div>
          <div class="card card-danger">
            <div class="card-header">
              <h4 class="card-title">
                <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
                  CSC Watchlist
                </a>
              </h4>
            </div>
            <div id="collapseThree" class="panel-collapse collapse">
              <div class="card-body">
                <table class="table">
                    <thead>
                      <tr>
                        <th>File Name</th>
                        <th>File Size</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>

                      <tr>
                        <td>HOI Watchlist.pdf</td>
                        <td>24.6 kb</td>
                        <td class="text-right py-0 align-middle">
                          <div class="btn-group btn-group-sm">
                            <a href="#" class="btn btn-secondary"><i class="fas fa-eye"></i></a>
                            <a href="#" class="btn btn-info"><i class="fas fa-file-download"></i></a>
                          </div>
                        </td>
    
                    </tbody>
                  </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /.card-body -->
    </div>
    <!-- /.card -->
  </div>
  <!-- /.col -->

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
<!-- ./wrapper -->
@stop