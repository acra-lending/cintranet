@extends('layouts.default')

@section('content')
<body class="hold-transition sidebar-mini">    
      <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1 class="m-0 text-dark">Sales</h1>
              </div><!-- /.col -->
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="/">Sales</a></li>
                  <li class="breadcrumb-item active">Forms</li>
                </ol>
              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->        
        <div class="col-lg-6">
          <div class="card card-danger">
            <div class="card-header border-0">
              <h3 class="card-title">Loan Files</h3>
              <div class="card-tools">
                </a>
              </div>
            </div>
            <div class="card-body table-responsive p-0">
              <table class="table table-striped table-valign-middle">
                <thead>
                <tr>
                  <th>Doc Type</th>
                  <th>Loan Amount</th>
                  <th>LTV</th>
                  <th>More</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>
                    <img src="{{ asset ('img/csc-logo-small.png') }}" alt="Product 1" class="img-circle img-size-32 mr-2">
                    Bank Statments
                  </td>
                  <td>$181,250 USD</td>
                  <td>
                    <div class="text-success mr-1">
                      80%
                    </div>
                  </td>
                  <td>
                    <a href="#" class="text-muted">
                      <i class="fas fa-file-alt"></i>
                    </a>
                  </td>
                </tr>
                <tr>
                  <td>
                    <img src="{{ asset ('img/csc-logo-small.png') }}" alt="Product 1" class="img-circle img-size-32 mr-2">
                    Full Doc
                  </td>
                  <td>$275,000 USD</td>
                  <td>
                    <div class="text-warning mr-1">
                      70%
                    </div>
                  </td>
                  <td>
                    <a href="#" class="text-muted">
                      <i class="fas fa-file-alt"></i>
                    </a>
                  </td>
                </tr>
                <tr>
                  <td>
                    <img src="{{ asset ('img/csc-logo-small.png') }}" alt="Product 1" class="img-circle img-size-32 mr-2">
                    Bank Statements
                  </td>
                  <td>$700,000 USD</td>
                  <td>
                    <div class="text-danger mr-1">
                      57%
                    </div>
                  </td>
                  <td>
                    <a href="#" class="text-muted">
                      <i class="fas fa-file-alt"></i>
                    </a>
                  </td>
                </tr>
                <tr>
                  <td>
                    <img src="{{ asset ('img/csc-logo-small.png') }}" alt="Product 1" class="img-circle img-size-32 mr-2">
                    Full Doc
                    <span class="badge bg-danger">NEW</span>
                  </td>
                  <td>$1,400,000 USD</td>
                  <td>
                    <div class="text-success mr-1">
                      90%
                    </div>
                  </td>
                  <td>
                    <a href="#" class="text-muted">
                      <i class="fas fa-file-alt"></i>
                    </a>
                  </td>
                </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    
      <!-- Control Sidebar -->
      <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
      </aside>
      <!-- /.control-sidebar -->
@stop
